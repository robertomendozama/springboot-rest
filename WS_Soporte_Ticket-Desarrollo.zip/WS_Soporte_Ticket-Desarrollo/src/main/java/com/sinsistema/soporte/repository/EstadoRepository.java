package com.sinsistema.soporte.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinsistema.soporte.model.*;

public interface EstadoRepository extends JpaRepository<Estado, Long>{

}
