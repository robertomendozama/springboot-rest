package com.sinsistema.soporte.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinsistema.soporte.model.*;

public interface PrioridadRepository extends JpaRepository<Prioridad, Long>{



}
